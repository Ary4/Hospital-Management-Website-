package com.arya.model;

public class one_string {
	String str;

	public String getStr() {
		return str;
	}

	public void setStr(String str) {
		this.str = str;
	}

	public one_string(String str) {
		super();
		this.str = str;
	}

	public one_string() {
		super();
	}
	

}
