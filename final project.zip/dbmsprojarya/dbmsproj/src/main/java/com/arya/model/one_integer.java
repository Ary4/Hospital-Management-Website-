package com.arya.model;

public class one_integer {
	
	int count;

	public one_integer(int count) {
		super();
		this.count = count;
	}
	
	public one_integer() {
		super();
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
	
	
	

}
