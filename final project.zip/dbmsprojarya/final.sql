-- MySQL dump 10.13  Distrib 5.7.27, for Linux (x86_64)
--
-- Host: localhost    Database: dbmsproj
-- ------------------------------------------------------
-- Server version	5.7.27-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `appointment`
--

DROP TABLE IF EXISTS `appointment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointment` (
  `appid` int(11) NOT NULL AUTO_INCREMENT,
  `d` int(11) DEFAULT NULL,
  `m` int(11) DEFAULT NULL,
  `y` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `doctorid` varchar(20) DEFAULT NULL,
  `pid` varchar(20) DEFAULT NULL,
  `department` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`appid`),
  KEY `app1` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointment`
--

LOCK TABLES `appointment` WRITE;
/*!40000 ALTER TABLE `appointment` DISABLE KEYS */;
INSERT INTO `appointment` VALUES (1,10,10,2020,1230,'docot1','pat','Ortho'),(3,10,10,2020,1230,'docot1','pat','Ortho'),(6,10,10,2020,1230,'docot1','pat','Ortho'),(8,10,10,2020,1230,'docot1','pat','Ortho'),(9,10,10,2019,1230,'docot1','pat2','Ortho'),(10,10,10,2020,1230,'docot1','pat2','Ortho'),(11,12,10,2020,1230,'doc2','pat2','Paed'),(12,12,10,2020,1230,'doc','pat2','Neuro'),(14,10,10,2020,1230,'docot1','pat2','Ortho'),(15,15,10,2019,1500,'doc','pat2','Neuro'),(16,14,10,2019,1230,'doc2','pat3','Paed'),(17,7,10,2019,1230,'doc2','pat3','Paed'),(18,10,10,2020,1230,'docot1','pat','Ortho'),(19,10,10,2020,1230,'docot1','user','Ortho'),(20,15,10,2019,1230,'docot1','user','Ortho');
/*!40000 ALTER TABLE `appointment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appointmentdetails`
--

DROP TABLE IF EXISTS `appointmentdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointmentdetails` (
  `appid` int(11) NOT NULL,
  `details` varchar(1000) NOT NULL,
  PRIMARY KEY (`appid`,`details`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointmentdetails`
--

LOCK TABLES `appointmentdetails` WRITE;
/*!40000 ALTER TABLE `appointmentdetails` DISABLE KEYS */;
INSERT INTO `appointmentdetails` VALUES (9,'someurl.com'),(11,'https://filebin.net/41ptq8x0p0ftlvo6'),(11,'https://filebin.net/vso10258surblv1f/1.png?t=s21idl6c'),(11,'someurl.com'),(17,'https://filebin.net/0qgpz426l6htlmy5'),(17,'https://filebin.net/0t3skz3jb09mp3ns'),(17,'someurl.com');
/*!40000 ALTER TABLE `appointmentdetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance`
--

DROP TABLE IF EXISTS `attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendance` (
  `empid` varchar(20) DEFAULT NULL,
  `d` int(11) DEFAULT NULL,
  `m` int(11) DEFAULT NULL,
  `y` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance`
--

LOCK TABLES `attendance` WRITE;
/*!40000 ALTER TABLE `attendance` DISABLE KEYS */;
INSERT INTO `attendance` VALUES ('user',13,10,2019,2110),('pat2',13,10,2019,2110),('pat3',13,10,2019,2110),('pat',13,10,2019,2142),('docot1',13,10,2019,2149),('docot1',14,10,2019,2151),('doc2',13,10,2019,2225),('user',14,10,2019,55),('pat2',14,10,2019,1345),('pat',14,10,2019,1435);
/*!40000 ALTER TABLE `attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cart` (
  `bookerid` varchar(20) NOT NULL,
  `medid` varchar(20) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `totalcost` int(11) DEFAULT NULL,
  PRIMARY KEY (`bookerid`,`medid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart`
--

LOCK TABLES `cart` WRITE;
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department` (
  `dname` varchar(20) NOT NULL,
  `dhod` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`dname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctors`
--

DROP TABLE IF EXISTS `doctors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctors` (
  `doctorid` varchar(20) NOT NULL,
  `sex` varchar(4) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `doj` date DEFAULT NULL,
  `salary` int(11) DEFAULT '100000',
  `degree` varchar(25) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `department` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`doctorid`),
  CONSTRAINT `d1` FOREIGN KEY (`doctorid`) REFERENCES `users` (`username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctors`
--

LOCK TABLES `doctors` WRITE;
/*!40000 ALTER TABLE `doctors` DISABLE KEYS */;
INSERT INTO `doctors` VALUES ('doc2',NULL,NULL,NULL,1000000,NULL,1,'Neuro'),('doc4',NULL,NULL,NULL,100000,NULL,1,'surgery'),('doc9',NULL,NULL,NULL,100000,NULL,1,'Paed'),('docot1',NULL,NULL,NULL,100000,NULL,1,'Ortho'),('ENTdoc',NULL,NULL,NULL,100000,NULL,1,'ENT'),('eyedoc',NULL,NULL,NULL,100000,NULL,1,'Eye');
/*!40000 ALTER TABLE `doctors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory` (
  `prodid` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`prodid`),
  CONSTRAINT `i1` FOREIGN KEY (`prodid`) REFERENCES `proddata` (`prodid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES (1,10),(3,17),(9,3),(10,3),(11,8),(12,0),(13,0);
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invtrans`
--

DROP TABLE IF EXISTS `invtrans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invtrans` (
  `prodid` int(11) DEFAULT NULL,
  `staffid` varchar(20) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `comments` varchar(200) DEFAULT NULL,
  `datntim` varchar(30) DEFAULT NULL,
  KEY `i2` (`prodid`),
  KEY `i3` (`staffid`),
  CONSTRAINT `i2` FOREIGN KEY (`prodid`) REFERENCES `proddata` (`prodid`),
  CONSTRAINT `i3` FOREIGN KEY (`staffid`) REFERENCES `staffs` (`staffid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invtrans`
--

LOCK TABLES `invtrans` WRITE;
/*!40000 ALTER TABLE `invtrans` DISABLE KEYS */;
INSERT INTO `invtrans` VALUES (1,'staff45',-1,'aaa','2019-39-10 07:39:37'),(1,'staff45',-2,'aaa','2019-42-10 07:42:35'),(1,'staff45',-1,'aaa','2019-43-10 07:43:09'),(1,'staff45',-1,'aaa','2019-43-10 07:43:23'),(1,'staff45',-2,'aise hi le rha hu','2019-26-10 08:26:46'),(1,'staff45',-1,'aaa','2019-28-10 08:28:34'),(10,'staff45',-10,'aaa','2019-35-10 08:35:34'),(10,'staff45',-10,'aaa','2019-35-10 08:35:47'),(10,'staff45',10,'aaa','2019-36-10 08:36:09'),(10,'staff45',14,'aaa','2019-36-10 08:36:17'),(11,'staff45',10,'aaa','2019-36-10 08:36:22'),(3,'staff45',15,'aaa','2019-36-10 08:36:27'),(9,'staff45',213,'aaa','2019-36-10 08:36:31'),(9,'staff45',-211,'aaa','2019-36-10 08:36:40'),(9,'staff45',1,'aaa','2019-38-10 08:38:37'),(1,'staff45',2,'aaa','2019-03-10 09:03:56'),(10,'s2',1,'aaa','2019-37-10 09:37:44'),(9,'s2',2,'aaa','2019-10-10 10:10:03'),(3,'s2',2,'date timme works okay now','2019-15-10 10:15:46'),(3,'staff45',2,'some purpose','2019-47-14 02:47:43');
/*!40000 ALTER TABLE `invtrans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `iid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `price` float DEFAULT NULL,
  PRIMARY KEY (`iid`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (11,'Plastic Folding Chair',1,3.5),(13,'Farmhouse Chair',1,12),(14,'Directors\' Chair',1,40),(15,'VIDEO PROJECTOR 2800 LUMENS',5,320),(16,'VIDEO PROJECTOR 4000 LUMENS',5,480),(18,'PROJECTION SCREEN',5,310),(19,'WOOD PODIUM',5,100),(20,'WOOD PODIUM',5,12),(21,'200 WATT JBL SPEAKER ',5,90),(22,'SOFAS',4,195),(23,'ROUND OTTOMAN',4,135),(24,'SQUARE OTTOMAN',4,135),(25,'SQUARE BENCH',4,135),(26,'PORTABLE GENERATOR 6000 WATTS',6,560),(27,'PORTABLE LIGHT TOWER ',6,570),(28,'Wood Folding Chair',1,12);
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicine`
--

DROP TABLE IF EXISTS `medicine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medicine` (
  `medid` varchar(20) NOT NULL,
  `quantity` int(11) DEFAULT '0',
  `threshold` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  PRIMARY KEY (`medid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicine`
--

LOCK TABLES `medicine` WRITE;
/*!40000 ALTER TABLE `medicine` DISABLE KEYS */;
INSERT INTO `medicine` VALUES ('Cipla-12',12,11,100),('Cipla-13',20,11,100),('Cipla-15',3,11,100),('Cipla-18',24,5,1500),('Cipla-19',5,11,100),('Montair-L',14,5,160);
/*!40000 ALTER TABLE `medicine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordercontains`
--

DROP TABLE IF EXISTS `ordercontains`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ordercontains` (
  `orderid` int(11) NOT NULL,
  `medid` varchar(20) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`orderid`,`medid`),
  KEY `oc2` (`medid`),
  CONSTRAINT `oc1` FOREIGN KEY (`orderid`) REFERENCES `orders` (`orderid`),
  CONSTRAINT `oc2` FOREIGN KEY (`medid`) REFERENCES `medicine` (`medid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordercontains`
--

LOCK TABLES `ordercontains` WRITE;
/*!40000 ALTER TABLE `ordercontains` DISABLE KEYS */;
INSERT INTO `ordercontains` VALUES (2,'Cipla-12',1),(2,'Cipla-13',1),(3,'Cipla-12',1),(3,'Cipla-13',3),(3,'Montair-L',3),(4,'Cipla-12',1),(5,'Cipla-12',1),(6,'Cipla-12',1),(6,'Cipla-13',1),(7,'Cipla-12',1),(8,'Cipla-13',2),(9,'Cipla-13',2),(10,'Montair-L',3),(11,'Cipla-13',3),(12,'Cipla-12',1),(13,'Cipla-12',1),(14,'Cipla-12',1),(15,'Cipla-13',2),(16,'Cipla-15',1),(17,'Cipla-15',2),(18,'Cipla-13',2),(19,'Cipla-15',3),(20,'Cipla-12',12),(20,'Cipla-13',2),(20,'Cipla-18',1),(20,'Montair-L',1),(21,'Cipla-18',2),(22,'Cipla-15',5),(23,'Cipla-18',2),(24,'Cipla-12',1),(25,'Cipla-13',1),(26,'Cipla-15',1),(27,'Cipla-15',1),(28,'Montair-L',3),(29,'Cipla-18',3),(30,'Montair-L',1),(31,'Montair-L',1);
/*!40000 ALTER TABLE `ordercontains` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `orderid` int(11) NOT NULL AUTO_INCREMENT,
  `bookerid` varchar(20) DEFAULT NULL,
  `totalprice` int(11) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`orderid`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (2,'pharma',200,'temporaray address'),(3,'pharma',880,'temporaray address'),(4,'pharma',100,'temporaray address'),(5,'pharma',100,'temporaray address'),(6,'pharma',200,'temporaray address'),(7,'pharma',100,'temporaray address'),(8,'pharma',200,'temporaray address'),(9,'pharma',200,'temporaray address'),(10,'pharma',480,'temporaray address'),(11,'pharma',300,'temporaray address'),(12,'pharma',100,'temporaray address'),(13,'pharma',100,'temporaray address'),(14,'pharma',100,'temporaray address'),(15,'user',200,'temporaray address'),(16,'user',100,'temporaray address'),(17,'user',200,'temporaray address'),(18,'pharma',200,'temporaray address'),(19,'pharma',300,'temporaray address'),(20,'pharma',3060,'temporaray address'),(21,'user',3000,'temporaray address'),(22,'pat',500,'temporaray address'),(23,'user',3000,'temporaray address'),(24,'user',100,'temporaray address'),(25,'user',100,'temporaray address'),(26,'user',100,'temporaray address'),(27,'pharma',100,'temporaray address'),(28,'pharma',480,'temporary address it works'),(29,'pat2',4500,'hostel1'),(30,'pat',160,' address'),(31,'user',160,'address works');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients` (
  `pid` varchar(20) NOT NULL,
  `bloodgroup` varchar(5) DEFAULT NULL,
  `previousdiseases` varchar(100) DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`pid`),
  CONSTRAINT `patient1` FOREIGN KEY (`pid`) REFERENCES `users` (`username`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES ('aaa',NULL,NULL,NULL,NULL),('pat',NULL,'i have depression','i forgot ','f'),('pat2',NULL,NULL,NULL,NULL),('pat3',NULL,NULL,NULL,NULL),('pat5',NULL,NULL,NULL,NULL),('user',NULL,'sad','dasdsad','f');
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proddata`
--

DROP TABLE IF EXISTS `proddata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proddata` (
  `prodid` int(11) NOT NULL AUTO_INCREMENT,
  `prodname` varchar(40) DEFAULT NULL,
  `threshold` int(11) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`prodid`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proddata`
--

LOCK TABLES `proddata` WRITE;
/*!40000 ALTER TABLE `proddata` DISABLE KEYS */;
INSERT INTO `proddata` VALUES (1,'aaa',10,'test'),(3,'abcka',12,'blab21'),(9,'aa',11,'aaa'),(10,'aa9321',11,'aaa'),(11,'praveen',5,'is a person'),(12,'saddas',11,'aaa'),(13,'trst',11,'aaa');
/*!40000 ALTER TABLE `proddata` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`arya`@`%`*/ /*!50003 TRIGGER prod1 AFTER INSERT ON proddata
FOR EACH ROW
BEGIN
INSERT INTO inventory VALUES(new.prodid,0);
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule` (
  `doctorid` varchar(20) NOT NULL,
  `day` varchar(10) NOT NULL,
  `timein` int(11) NOT NULL,
  `timeout` int(11) DEFAULT NULL,
  PRIMARY KEY (`doctorid`,`day`,`timein`),
  CONSTRAINT `schedulef1` FOREIGN KEY (`doctorid`) REFERENCES `doctors` (`doctorid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
INSERT INTO `schedule` VALUES ('doc2','mon',1130,1330),('doc2','tue',1130,1330),('docot1','fri',1130,1330),('docot1','mon',1230,1330),('docot1','sat',1130,1330),('docot1','sun',1130,1330),('docot1','thr',1130,1330),('docot1','tue',1130,1330),('docot1','wed',1130,1330);
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staffs`
--

DROP TABLE IF EXISTS `staffs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staffs` (
  `staffid` varchar(20) NOT NULL,
  `salary` int(11) DEFAULT '50000',
  `sex` varchar(4) DEFAULT NULL,
  PRIMARY KEY (`staffid`),
  CONSTRAINT `s1` FOREIGN KEY (`staffid`) REFERENCES `users` (`username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staffs`
--

LOCK TABLES `staffs` WRITE;
/*!40000 ALTER TABLE `staffs` DISABLE KEYS */;
INSERT INTO `staffs` VALUES ('aaa21',50000,NULL),('s2',50000,NULL),('s3',50000,NULL),('staff45',50000,NULL);
/*!40000 ALTER TABLE `staffs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t1`
--

DROP TABLE IF EXISTS `t1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t1` (
  `id` int(11) NOT NULL,
  `c2` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t1`
--

LOCK TABLES `t1` WRITE;
/*!40000 ALTER TABLE `t1` DISABLE KEYS */;
INSERT INTO `t1` VALUES (2,88),(6,99);
/*!40000 ALTER TABLE `t1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t2`
--

DROP TABLE IF EXISTS `t2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t2` (
  `id` int(11) NOT NULL,
  `c2` int(11) NOT NULL,
  PRIMARY KEY (`id`,`c2`),
  CONSTRAINT `f100` FOREIGN KEY (`id`) REFERENCES `t1` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t2`
--

LOCK TABLES `t2` WRITE;
/*!40000 ALTER TABLE `t2` DISABLE KEYS */;
/*!40000 ALTER TABLE `t2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test`
--

DROP TABLE IF EXISTS `test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test` (
  `i` int(11) DEFAULT NULL,
  `j` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test`
--

LOCK TABLES `test` WRITE;
/*!40000 ALTER TABLE `test` DISABLE KEYS */;
/*!40000 ALTER TABLE `test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `enabled` int(11) DEFAULT '1',
  `name` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `phone` varchar(13) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('aaa','aaa',1,'aaa','aaa','111'),('aaa21','aaa',1,'aaa','aaa','111'),('arya','123456',1,'arya','arya','123425455'),('doc2','aaa',1,'aaa','aaa','111'),('doc4','aaa',1,'aaa','aaa','111'),('doc9','aaa',1,'aaa','aaa','111'),('docot1','aaa',1,'aaa','aaa','111'),('ENTdoc','aaa',1,'aaa','aaa','111'),('eyedoc','aaa',1,'aaa','aaa','111'),('pat','aaa',1,'works','kka@kjjksa','9839122'),('pat2','aaa',1,'aaa','aaa','111'),('pat3','aaa',1,'aaa','aaa','111'),('pat5','aaa',1,'aaa','aaa','111'),('pharma','aaa',1,'aaa','aaa@aaa','12231'),('s2','aaa',1,'aaa','aaa','111'),('s3','aaa',1,'aaa','aaa','111'),('staff1','aaa',1,'sssa','aaa','111'),('staff45','aaa',1,'aaa','aaa','111'),('user','aaa',1,'arya','cca@cc','31232182');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER auto_role
AFTER INSERT on users
FOR EACH ROW
BEGIN
INSERT INTO users_roles VALUES(new.username,'ROLE_USER');
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `users_roles`
--

DROP TABLE IF EXISTS `users_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_roles` (
  `user` varchar(20) NOT NULL,
  `role` varchar(20) NOT NULL,
  PRIMARY KEY (`user`,`role`),
  CONSTRAINT `f1` FOREIGN KEY (`user`) REFERENCES `users` (`username`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_roles`
--

LOCK TABLES `users_roles` WRITE;
/*!40000 ALTER TABLE `users_roles` DISABLE KEYS */;
INSERT INTO `users_roles` VALUES ('aaa','ROLE_USER'),('aaa21','ROLE_STAFF'),('arya','ROLE_ADMIN'),('doc2','ROLE_DOCTOR'),('doc4','ROLE_DOCTOR'),('doc9','ROLE_DOCTOR'),('docot1','ROLE_DOCTOR'),('ENTdoc','ROLE_DOCTOR'),('eyedoc','ROLE_DOCTOR'),('pat','ROLE_USER'),('pat2','ROLE_USER'),('pat3','ROLE_USER'),('pat5','ROLE_USER'),('pharma','ROLE_PHARMA'),('s2','ROLE_STAFF'),('s3','ROLE_STAFF'),('staff1','ROLE_STAFF'),('staff45','ROLE_STAFF'),('user','ROLE_USER');
/*!40000 ALTER TABLE `users_roles` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER auto_doc_fill AFTER UPDATE ON users_roles FOR EACH ROW
BEGIN
IF new.role = 'ROLE_DOCTOR' THEN
INSERT INTO doctors (doctorid) VALUES (new.user);
END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER auto_staff_fill AFTER UPDATE ON users_roles FOR EACH ROW
BEGIN
IF new.role = 'ROLE_STAFF' THEN
INSERT INTO staffs (staffid) VALUES (new.user);
END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-14 15:10:50
